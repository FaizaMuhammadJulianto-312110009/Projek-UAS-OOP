import javax.swing.*;

class Show {

    public static void main(String[] args) {

        JFrame jFrame;

        jFrame = new JFrame();
        jFrame.setSize(400,400);
        jFrame.setVisible(true);

        JOptionPane.showMessageDialog(jFrame, "Selamat Pagi Faiza Muhammad J.");
        JOptionPane.showMessageDialog(null, "Terima Kasih, Semoga Harimu Menyenangkan");
    }
}