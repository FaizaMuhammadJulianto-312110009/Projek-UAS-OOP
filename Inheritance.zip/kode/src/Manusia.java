public class Manusia {
    String nama;
    String jenisKelamin;
    int umur;
    String alamat;

    public void cetakInfo() {
        System.out.println("Nama\t\t: " + this.nama);
        System.out.println("Jenis Kelamin\t: " + this.jenisKelamin);
        System.out.println("Umur\t\t: " + this.umur);
        System.out.println("Alamat\t\t: " + this.alamat);
    }
}